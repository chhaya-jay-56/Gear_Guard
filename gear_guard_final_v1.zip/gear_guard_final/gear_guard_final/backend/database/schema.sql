CREATE DATABASE IF NOT EXISTS gear_guard_db;
USE gear_guard_db;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS teams;
CREATE TABLE teams (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    members TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS equipment;
CREATE TABLE equipment (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    status VARCHAR(50) DEFAULT 'operational',
    team_id VARCHAR(50),
    meta JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS requests;
CREATE TABLE requests (
    id VARCHAR(50) PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    description TEXT,
    equipment_id VARCHAR(50),
    team_id VARCHAR(50),
    priority VARCHAR(20) DEFAULT 'normal',
    status VARCHAR(50) DEFAULT 'new',
    type VARCHAR(50) DEFAULT 'corrective',
    created_by VARCHAR(50),
    due_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME
);

-- seed initial teams and equipment (matches frontend mockData)
INSERT INTO teams (id, name, members) VALUES
('it-support', 'IT Support', '["tech1","tech2","tech3"]'),
('mechanical', 'Mechanical', '["tech4","tech5"]'),
('facility', 'Facility', '["tech6","tech7"]');

INSERT INTO equipment (id, name, status, team_id) VALUES
('eq1', 'HP Printer', 'operational', 'it-support'),
('eq2', 'Canon Copier', 'operational', 'it-support'),
('eq3', 'Dell Desktop', 'under_maintenance', 'it-support'),
('eq4', 'CNC Machine', 'operational', 'mechanical'),
('eq5', 'Hydraulic Drill', 'operational', 'mechanical'),
('eq6', 'HVAC Unit', 'operational', 'facility'),
('eq7', 'Elevator', 'operational', 'facility'),
('eq8', 'Water Pump', 'operational', 'facility');
