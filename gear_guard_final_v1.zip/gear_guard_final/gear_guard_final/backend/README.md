Backend setup

1. Install dependencies (from `backend` folder):

```
npm install
```

2. Create a `.env` file (copy `.env.example`) and set DB credentials.

3. Initialize the database schema (using MySQL client):

```
mysql -u <user> -p < database/schema.sql
```

4. Start the server:

```
npm start
```

Server listens on port 5000 by default.

Troubleshooting
1. If you see `ECONNREFUSED` when the server starts, ensure MySQL is running locally and listening on port `3306`.
2. On Windows, confirm MySQL service is started (`services.msc`) or start via `net start mysql` if installed as a service.
3. If using a remote DB, update the `.env` with the correct `DB_HOST` and make sure the host allows remote connections and your IP is whitelisted.
4. Use `mysql -h <host> -u <user> -p` to verify you can connect from this machine.
