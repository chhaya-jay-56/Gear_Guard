require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./config/db');

const app = express();
app.use(cors());
app.use(express.json());

// verify connection by getting a connection from the pool
db.getConnection()
  .then(conn => {
    conn.release();
    console.log('MySQL connected (pool)');
  })
  .catch(err => console.error('MySQL connection failed', err));

app.post("/api/users", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).send('Missing fields');
    const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    await db.query(sql, [name, email, password]);
    res.send("Data stored successfully");
  } catch (err) {
    console.error('DB query error', err);
    res.status(500).send("DB error");
  }
});

// Requests endpoints
app.get('/api/requests', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM requests ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    console.error('GET requests error', err);
    res.status(500).send('DB error');
  }
});

app.post('/api/requests', async (req, res) => {
  try {
    const {
      id,
      subject,
      description,
      equipmentId,
      teamId,
      priority,
      status,
      type,
      createdBy,
      dueDate
    } = req.body;

    const requestId = id || `req${Date.now()}`;
    const sql = `INSERT INTO requests (id, subject, description, equipment_id, team_id, priority, status, type, created_by, due_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    await db.query(sql, [requestId, subject, description, equipmentId, teamId, priority, status, type, createdBy, dueDate ? new Date(dueDate) : null]);
    res.json({ id: requestId });
  } catch (err) {
    console.error('POST requests error', err);
    res.status(500).send('DB error');
  }
});

app.put('/api/requests/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const updates = req.body;

    const fields = [];
    const values = [];
    for (const key of Object.keys(updates)) {
      if (key === 'equipmentId') {
        fields.push('equipment_id = ?');
        values.push(updates[key]);
      } else if (key === 'teamId') {
        fields.push('team_id = ?');
        values.push(updates[key]);
      } else if (key === 'dueDate' || key === 'completedAt') {
        fields.push(`${key === 'completedAt' ? 'completed_at' : 'due_date'} = ?`);
        values.push(updates[key] ? new Date(updates[key]) : null);
      } else {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    }
    if (fields.length === 0) return res.status(400).send('No updates');
    const sql = `UPDATE requests SET ${fields.join(', ')} WHERE id = ?`;
    values.push(id);
    await db.query(sql, values);
    res.send('OK');
  } catch (err) {
    console.error('PUT requests error', err);
    res.status(500).send('DB error');
  }
});

// delete request
app.delete('/api/requests/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const sql = 'DELETE FROM requests WHERE id = ?';
    const [result] = await db.query(sql, [id]);
    res.json({ deleted: true });
  } catch (err) {
    console.error('DELETE requests error', err);
    res.status(500).send('DB error');
  }
});

// delete equipment
app.delete('/api/equipment/:id', async (req, res) => {
  try {
    const id = req.params.id;
    // optionally delete related requests first (not enforced)
    await db.query('DELETE FROM requests WHERE equipment_id = ?', [id]);
    await db.query('DELETE FROM equipment WHERE id = ?', [id]);
    res.json({ deleted: true });
  } catch (err) {
    console.error('DELETE equipment error', err);
    res.status(500).send('DB error');
  }
});

// Equipment endpoints
app.get('/api/equipment', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM equipment');
    res.json(rows);
  } catch (err) {
    console.error('GET equipment error', err);
    res.status(500).send('DB error');
  }
});

app.post('/api/equipment', async (req, res) => {
  try {
    const { id, name, status, teamId, meta } = req.body;
    const sql = `INSERT INTO equipment (id, name, status, team_id, meta) VALUES (?, ?, ?, ?, ?)`;
    await db.query(sql, [id, name, status || 'operational', teamId, meta ? JSON.stringify(meta) : null]);
    res.json({ id });
  } catch (err) {
    console.error('POST equipment error', err);
    res.status(500).send('DB error');
  }
});

// Teams
app.get('/api/teams', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM teams');
    // ensure members is an array when returned to frontend
    const mapped = rows.map(r => {
      let members = [];
      if (r.members) {
        try {
          members = JSON.parse(r.members);
          if (!Array.isArray(members)) members = [];
        } catch (e) {
          members = String(r.members).split(',').map((s) => s.trim()).filter(Boolean);
        }
      }
      return { id: r.id, name: r.name, members, created_at: r.created_at };
    });
    res.json(mapped);
  } catch (err) {
    console.error('GET teams error', err);
    res.status(500).send('DB error');
  }
});

app.listen(5000, () => console.log("Server running on port 5000"));
