import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AppProvider } from './contexts/AppContext';
import { Login } from './components/Login';
import { EmployeeDashboard } from './components/employee/EmployeeDashboard';
import { TechnicianDashboard } from './components/technician/TechnicianDashboard';
import { ManagerDashboard } from './components/manager/ManagerDashboard';

const AppContent = () => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return <Login />;
  }

  switch (currentUser.role) {
    case 'employee':
      return <EmployeeDashboard />;
    case 'technician':
      return <TechnicianDashboard />;
    case 'manager':
      return <ManagerDashboard />;
    default:
      return <Login />;
  }
};

function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
}

export default App;
