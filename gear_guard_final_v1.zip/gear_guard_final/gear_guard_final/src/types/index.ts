export type Role = 'employee' | 'technician' | 'manager';

export type Priority = 'low' | 'normal' | 'high';

export type Status = 'new' | 'in_progress' | 'repaired' | 'scrap';

export type RequestType = 'corrective' | 'preventive';

export type EquipmentStatus = 'operational' | 'under_maintenance' | 'scrapped';

export interface User {
  id: string;
  username: string;
  password: string;
  name: string;
  role: Role;
  teamId?: string;
  avatar?: string;
}

export interface Team {
  id: string;
  name: string;
  members: string[];
}

export interface Equipment {
  id: string;
  name: string;
  teamId: string;
  status: EquipmentStatus;
}

export interface MaintenanceRequest {
  id: string;
  subject: string;
  description: string;
  equipmentId: string;
  teamId: string;
  priority: Priority;
  status: Status;
  type: RequestType;
  createdBy: string;
  assignedTo?: string;
  createdAt: string;
  dueDate?: string;
  completedAt?: string;
  duration?: number;
  workNotes?: string;
}
