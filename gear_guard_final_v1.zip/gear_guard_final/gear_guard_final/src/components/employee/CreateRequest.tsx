import { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { Priority } from '../../types';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export const CreateRequest = () => {
  const { equipment, addRequest, getEquipmentById } = useApp();
  const { currentUser } = useAuth();
  const [subject, setSubject] = useState('');
  const [equipmentId, setEquipmentId] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('normal');
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentUser) return;

    const selectedEquipment = getEquipmentById(equipmentId);
    if (!selectedEquipment) return;

    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + (priority === 'high' ? 1 : priority === 'normal' ? 3 : 7));

    addRequest({
      subject,
      description,
      equipmentId,
      teamId: selectedEquipment.teamId,
      priority,
      status: 'new',
      type: 'corrective',
      createdBy: currentUser.id,
      dueDate: dueDate.toISOString(),
    });

    setSubject('');
    setEquipmentId('');
    setDescription('');
    setPriority('normal');
    setShowSuccess(true);

    setTimeout(() => {
      setShowSuccess(false);
    }, 3000);
  };

  const selectedEquipment = equipmentId ? getEquipmentById(equipmentId) : null;

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Create Maintenance Request</h2>

        {showSuccess && (
          <div className="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg flex items-center space-x-2">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            <span>Request submitted successfully! Your request has been added to the queue.</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-2">
              Subject *
            </label>
            <input
              id="subject"
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none transition"
              placeholder="Brief description of the issue"
            />
          </div>

          <div>
            <label htmlFor="equipment" className="block text-sm font-medium text-slate-700 mb-2">
              Equipment *
            </label>
            <select
              id="equipment"
              required
              value={equipmentId}
              onChange={(e) => setEquipmentId(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none transition"
            >
              <option value="">Select equipment</option>
              {equipment.map((eq) => (
                <option key={eq.id} value={eq.id}>
                  {eq.name}
                </option>
              ))}
            </select>
            {selectedEquipment && (
              <div className="mt-2 flex items-center space-x-2 text-sm text-slate-600">
                <AlertCircle className="w-4 h-4" />
                <span>
                  Will be assigned to: <span className="font-medium">{getEquipmentById(equipmentId)?.teamId.replace('-', ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')} Team</span>
                </span>
              </div>
            )}
          </div>

          <div>
            <label htmlFor="priority" className="block text-sm font-medium text-slate-700 mb-2">
              Priority *
            </label>
            <select
              id="priority"
              required
              value={priority}
              onChange={(e) => setPriority(e.target.value as Priority)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none transition"
            >
              <option value="low">Low</option>
              <option value="normal">Normal</option>
              <option value="high">High</option>
            </select>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-2">
              Description *
            </label>
            <textarea
              id="description"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none transition resize-none"
              placeholder="Detailed description of the issue..."
            />
          </div>

          <button
            type="submit"
            className="w-full bg-slate-900 text-white py-3 rounded-lg font-medium hover:bg-slate-800 transition"
          >
            Submit Request
          </button>
        </form>
      </div>
    </div>
  );
};
