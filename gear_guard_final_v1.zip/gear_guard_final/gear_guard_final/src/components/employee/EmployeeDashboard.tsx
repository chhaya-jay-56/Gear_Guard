import { useState } from 'react';
import { Navbar } from '../shared/Navbar';
import { CreateRequest } from './CreateRequest';
import { MyRequests } from './MyRequests';

export const EmployeeDashboard = () => {
  const [activeView, setActiveView] = useState('create');

  const views = [
    { id: 'create', label: 'Create Request' },
    { id: 'my-requests', label: 'My Requests' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activeView={activeView} onViewChange={setActiveView} views={views} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'create' && <CreateRequest />}
        {activeView === 'my-requests' && <MyRequests />}
      </div>
    </div>
  );
};
