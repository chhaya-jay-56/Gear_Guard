import { useState } from 'react';
import { Navbar } from '../shared/Navbar';
import { TechStats } from './TechStats';
import { KanbanBoard } from './KanbanBoard';
import { Calendar } from './Calendar';

export const TechnicianDashboard = () => {
  const [activeView, setActiveView] = useState('dashboard');

  const views = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'kanban', label: 'Kanban' },
    { id: 'calendar', label: 'Calendar' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activeView={activeView} onViewChange={setActiveView} views={views} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'dashboard' && (
          <>
            <TechStats />
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-4">My Team's Requests</h2>
            </div>
            <KanbanBoard />
          </>
        )}
        {activeView === 'kanban' && <KanbanBoard />}
        {activeView === 'calendar' && <Calendar />}
      </div>
    </div>
  );
};
