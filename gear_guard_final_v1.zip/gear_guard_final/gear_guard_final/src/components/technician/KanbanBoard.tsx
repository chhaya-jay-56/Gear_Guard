import { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { MaintenanceRequest, Status } from '../../types';
import { isOverdue } from '../../utils/dateUtils';
import { X } from 'lucide-react';

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'high':
      return 'bg-red-100 text-red-700 border-red-200';
    case 'normal':
      return 'bg-blue-100 text-blue-700 border-blue-200';
    case 'low':
      return 'bg-green-100 text-green-700 border-green-200';
    default:
      return 'bg-slate-100 text-slate-700 border-slate-200';
  }
};

interface KanbanBoardProps {
  teamFilter?: string;
  showAllTeams?: boolean;
}

interface CompletionModalProps {
  request: MaintenanceRequest;
  onClose: () => void;
  onComplete: (duration: number, notes: string) => void;
}

const CompletionModal = ({ request, onClose, onComplete }: CompletionModalProps) => {
  const [duration, setDuration] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const durationNum = parseFloat(duration);
    if (durationNum > 0) {
      onComplete(durationNum, notes);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-slate-900">Complete Request</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="duration" className="block text-sm font-medium text-slate-700 mb-2">
              Duration (hours) *
            </label>
            <input
              id="duration"
              type="number"
              step="0.5"
              min="0.5"
              required
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none"
              placeholder="e.g., 2.5"
            />
          </div>

          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-slate-700 mb-2">
              Work Notes *
            </label>
            <textarea
              id="notes"
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none resize-none"
              placeholder="Describe the work performed..."
            />
          </div>

          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition"
            >
              Complete
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const KanbanBoard = ({ teamFilter, showAllTeams = false }: KanbanBoardProps) => {
  const { requests, updateRequest, getEquipmentById, teams } = useApp();
  const { currentUser, users } = useAuth();
  const [draggedItem, setDraggedItem] = useState<MaintenanceRequest | null>(null);
  const [completionModalRequest, setCompletionModalRequest] = useState<MaintenanceRequest | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<string>('');

  const filterTeamId = teamFilter || selectedTeam || (showAllTeams ? '' : currentUser?.teamId);

  const filteredRequests = requests.filter((req) => {
    if (!showAllTeams && !filterTeamId) return false;
    return filterTeamId ? req.teamId === filterTeamId : true;
  });

  const columns: { status: Status; title: string; color: string }[] = [
    { status: 'new', title: 'New', color: 'bg-slate-50 border-slate-200' },
    { status: 'in_progress', title: 'In Progress', color: 'bg-blue-50 border-blue-200' },
    { status: 'repaired', title: 'Repaired', color: 'bg-green-50 border-green-200' },
    { status: 'scrap', title: 'Scrap', color: 'bg-red-50 border-red-200' },
  ];

  const handleDragStart = (request: MaintenanceRequest) => {
    setDraggedItem(request);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (status: Status) => {
    if (!draggedItem) return;

    if (status === 'repaired' && draggedItem.status === 'in_progress') {
      setCompletionModalRequest(draggedItem);
      setDraggedItem(null);
      return;
    }

    updateRequest(draggedItem.id, { status });
    setDraggedItem(null);
  };

  const handleAssignToMe = (requestId: string) => {
    if (currentUser) {
      updateRequest(requestId, { assignedTo: currentUser.id, status: 'in_progress' });
    }
  };

  const handleAssignTo = (requestId: string, userId: string) => {
    updateRequest(requestId, { assignedTo: userId, status: 'in_progress' });
  };

  const handleComplete = (duration: number, notes: string) => {
    if (completionModalRequest) {
      updateRequest(completionModalRequest.id, {
        status: 'repaired',
        duration,
        workNotes: notes,
      });
    }
  };

  const { deleteRequest } = useApp();

  const handleDelete = (requestId: string) => {
    if (!currentUser) return;
    if (currentUser.role !== 'manager' && currentUser.role !== 'technician') return;
    if (!confirm('Delete this request? This action cannot be undone.')) return;
    deleteRequest(requestId);
  };

  const getAssignedUser = (userId?: string) => {
    if (!userId) return null;
    return users.find((u) => u.id === userId);
  };

  const getTeamMembers = (teamId: string) => {
    const team = teams.find((t) => t.id === teamId);
    return team ? team.members : [];
  };

  return (
    <div>
      {showAllTeams && (
        <div className="mb-6">
          <label htmlFor="teamFilter" className="block text-sm font-medium text-slate-700 mb-2">
            Filter by Team
          </label>
          <select
            id="teamFilter"
            value={selectedTeam}
            onChange={(e) => setSelectedTeam(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none"
          >
            <option value="">All Teams</option>
            {teams.map((team) => (
              <option key={team.id} value={team.id}>
                {team.name}
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {columns.map((column) => {
          const columnRequests = filteredRequests.filter((req) => req.status === column.status);

          return (
            <div
              key={column.status}
              className={`${column.color} rounded-xl border-2 p-4 min-h-[500px]`}
              onDragOver={handleDragOver}
              onDrop={() => handleDrop(column.status)}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-slate-900">{column.title}</h3>
                <span className="bg-white px-2 py-1 rounded-full text-sm font-medium text-slate-700">
                  {columnRequests.length}
                </span>
              </div>

              <div className="space-y-3">
                {columnRequests.map((request) => {
                  const equipment = getEquipmentById(request.equipmentId);
                  const assignedUser = getAssignedUser(request.assignedTo);
                  const teamMembers = getTeamMembers(request.teamId);
                  const overdueStatus = isOverdue(request.dueDate);

                  return (
                    <div
                      key={request.id}
                      draggable
                      onDragStart={() => handleDragStart(request)}
                      className={`bg-white rounded-lg p-4 shadow-sm cursor-move hover:shadow-md transition border-2 ${
                        overdueStatus && request.status !== 'repaired' && request.status !== 'scrap'
                          ? 'border-red-500'
                          : 'border-transparent'
                      }`}
                    >
                      <h4 className="font-medium text-slate-900 mb-2">{request.subject}</h4>
                      <p className="text-sm text-slate-600 mb-3">{equipment?.name}</p>

                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded border ${getPriorityColor(request.priority)}`}>
                        {request.priority.charAt(0).toUpperCase() + request.priority.slice(1)}
                      </span>

                      {assignedUser && (
                        <div className="flex items-center space-x-2 mt-3 pt-3 border-t border-slate-200">
                          <div className="bg-slate-900 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">
                            {assignedUser.avatar}
                          </div>
                          <span className="text-xs text-slate-600">{assignedUser.name}</span>
                        </div>
                      )}

                      {(currentUser?.role === 'manager' || currentUser?.role === 'technician') && (
                        <div className="mt-3 flex space-x-2">
                          <button
                            onClick={() => handleDelete(request.id)}
                            className="px-3 py-1 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
                          >
                            Delete
                          </button>
                        </div>
                      )}

                      {!request.assignedTo && request.status === 'new' && (
                        <div className="mt-3 pt-3 border-t border-slate-200">
                          {!showAllTeams && (
                            <button
                              onClick={() => handleAssignToMe(request.id)}
                              className="w-full bg-slate-900 text-white text-sm py-2 rounded-lg hover:bg-slate-800 transition"
                            >
                              Assign to Me
                            </button>
                          )}
                          {showAllTeams && (
                            <select
                              onChange={(e) => {
                                if (e.target.value) {
                                  handleAssignTo(request.id, e.target.value);
                                }
                              }}
                              value=""
                              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none"
                            >
                              <option value="">Assign to...</option>
                              {teamMembers.map((memberId) => {
                                const member = users.find((u) => u.id === memberId);
                                return member ? (
                                  <option key={member.id} value={member.id}>
                                    {member.name}
                                  </option>
                                ) : null;
                              })}
                            </select>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {completionModalRequest && (
        <CompletionModal
          request={completionModalRequest}
          onClose={() => setCompletionModalRequest(null)}
          onComplete={handleComplete}
        />
      )}
    </div>
  );
};
