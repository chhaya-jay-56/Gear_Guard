import { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { getMonthDays, isSameDay } from '../../utils/dateUtils';

interface CalendarProps {
  showAllTypes?: boolean;
}

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const Calendar = ({ showAllTypes = false }: CalendarProps) => {
  const { requests, getEquipmentById } = useApp();
  const { currentUser } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());

  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  const today = new Date();

  const monthDays = getMonthDays(currentYear, currentMonth);

  const filteredRequests = requests.filter((req) => {
    if (!showAllTypes && req.type !== 'preventive') return false;
    if (!showAllTypes && currentUser?.teamId && req.teamId !== currentUser.teamId) return false;
    return true;
  });

  const getRequestsForDay = (day: Date) => {
    return filteredRequests.filter((req) => {
      if (req.dueDate) {
        return isSameDay(new Date(req.dueDate), day);
      }
      return false;
    });
  };

  const getRequestColor = (type: string, status: string) => {
    if (status === 'repaired') return 'bg-green-500';
    if (status === 'scrap') return 'bg-red-500';
    if (status === 'in_progress') return 'bg-blue-500';
    if (type === 'preventive') return 'bg-purple-500';
    return 'bg-slate-500';
  };

  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth + 1, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">
          {MONTHS[currentMonth]} {currentYear}
        </h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={goToToday}
            className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
          >
            Today
          </button>
          <button
            onClick={goToPreviousMonth}
            className="p-2 text-slate-700 hover:bg-slate-100 rounded-lg transition"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={goToNextMonth}
            className="p-2 text-slate-700 hover:bg-slate-100 rounded-lg transition"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {WEEKDAYS.map((day) => (
          <div key={day} className="text-center text-sm font-medium text-slate-600 py-2">
            {day}
          </div>
        ))}

        {monthDays.map((day, index) => {
          const isCurrentMonth = day.getMonth() === currentMonth;
          const isToday = isSameDay(day, today);
          const dayRequests = getRequestsForDay(day);

          return (
            <div
              key={index}
              className={`min-h-[100px] p-2 rounded-lg border-2 transition ${
                isCurrentMonth
                  ? 'bg-white border-slate-200'
                  : 'bg-slate-50 border-slate-100'
              } ${isToday ? 'border-slate-900' : ''}`}
            >
              <div
                className={`text-sm font-medium mb-1 ${
                  isCurrentMonth ? 'text-slate-900' : 'text-slate-400'
                } ${isToday ? 'bg-slate-900 text-white w-6 h-6 rounded-full flex items-center justify-center' : ''}`}
              >
                {day.getDate()}
              </div>

              <div className="space-y-1">
                {dayRequests.map((request) => {
                  const equipment = getEquipmentById(request.equipmentId);
                  return (
                    <div
                      key={request.id}
                      className={`${getRequestColor(request.type, request.status)} text-white text-xs p-1 rounded truncate`}
                      title={`${request.subject} - ${equipment?.name}`}
                    >
                      {request.subject}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 flex items-center justify-center space-x-6 text-sm">
        {showAllTypes && (
          <>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-purple-500 rounded"></div>
              <span className="text-slate-600">Preventive</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-slate-500 rounded"></div>
              <span className="text-slate-600">Corrective</span>
            </div>
          </>
        )}
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-500 rounded"></div>
          <span className="text-slate-600">In Progress</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-green-500 rounded"></div>
          <span className="text-slate-600">Completed</span>
        </div>
      </div>
    </div>
  );
};
