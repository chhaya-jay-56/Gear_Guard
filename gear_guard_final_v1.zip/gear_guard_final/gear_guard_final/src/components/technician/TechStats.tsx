import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { Wrench, Clock } from 'lucide-react';

export const TechStats = () => {
  const { requests } = useApp();
  const { currentUser } = useAuth();

  const myTeamRequests = requests.filter((req) => req.teamId === currentUser?.teamId);
  const inProgress = myTeamRequests.filter((req) => req.assignedTo === currentUser?.id && req.status === 'in_progress').length;
  const newInQueue = myTeamRequests.filter((req) => !req.assignedTo && req.status === 'new').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">In Progress</p>
            <p className="text-3xl font-bold text-slate-900 mt-2">{inProgress}</p>
          </div>
          <div className="bg-blue-100 p-3 rounded-lg">
            <Wrench className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">New in Queue</p>
            <p className="text-3xl font-bold text-slate-900 mt-2">{newInQueue}</p>
          </div>
          <div className="bg-slate-100 p-3 rounded-lg">
            <Clock className="w-6 h-6 text-slate-600" />
          </div>
        </div>
      </div>
    </div>
  );
};
