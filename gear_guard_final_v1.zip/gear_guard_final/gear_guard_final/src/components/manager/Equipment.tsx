import { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { MaintenanceRequest } from '../../types';
import { Search, X, History } from 'lucide-react';
import { formatDate } from '../../utils/dateUtils';

const getStatusColor = (status: string) => {
  switch (status) {
    case 'operational':
      return 'bg-green-100 text-green-700 border-green-200';
    case 'under_maintenance':
      return 'bg-blue-100 text-blue-700 border-blue-200';
    case 'scrapped':
      return 'bg-red-100 text-red-700 border-red-200';
    default:
      return 'bg-slate-100 text-slate-700 border-slate-200';
  }
};

interface HistoryModalProps {
  equipmentId: string;
  equipmentName: string;
  requests: MaintenanceRequest[];
  onClose: () => void;
}

const HistoryModal = ({ equipmentId, equipmentName, requests, onClose }: HistoryModalProps) => {
  const equipmentRequests = requests.filter((req) => req.equipmentId === equipmentId);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[80vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-slate-200">
          <div>
            <h3 className="text-xl font-bold text-slate-900">Maintenance History</h3>
            <p className="text-sm text-slate-600 mt-1">{equipmentName}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {equipmentRequests.length === 0 ? (
            <div className="text-center py-8 text-slate-600">
              No maintenance history available
            </div>
          ) : (
            <div className="space-y-4">
              {equipmentRequests.map((request) => (
                <div key={request.id} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-slate-900">{request.subject}</h4>
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded border ${
                      request.status === 'repaired' ? 'bg-green-100 text-green-700 border-green-200' :
                      request.status === 'in_progress' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                      request.status === 'scrap' ? 'bg-red-100 text-red-700 border-red-200' :
                      'bg-slate-100 text-slate-700 border-slate-200'
                    }`}>
                      {request.status.replace('_', ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mb-3">{request.description}</p>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-500">Created:</span>
                      <span className="ml-2 text-slate-900">{formatDate(request.createdAt)}</span>
                    </div>
                    {request.completedAt && (
                      <div>
                        <span className="text-slate-500">Completed:</span>
                        <span className="ml-2 text-slate-900">{formatDate(request.completedAt)}</span>
                      </div>
                    )}
                    {request.duration && (
                      <div>
                        <span className="text-slate-500">Duration:</span>
                        <span className="ml-2 text-slate-900">{request.duration}h</span>
                      </div>
                    )}
                  </div>
                  {request.workNotes && (
                    <div className="mt-3 pt-3 border-t border-slate-300">
                      <span className="text-xs font-medium text-slate-500">Work Notes:</span>
                      <p className="text-sm text-slate-700 mt-1">{request.workNotes}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const Equipment = () => {
  const { equipment, requests, getTeamById, deleteEquipment } = useApp();
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEquipment, setSelectedEquipment] = useState<string | null>(null);

  const filteredEquipment = equipment.filter((eq) =>
    eq.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getMaintenanceCount = (equipmentId: string) => {
    return requests.filter((req) => req.equipmentId === equipmentId).length;
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-4">Equipment Management</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search equipment..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent outline-none"
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs font-medium text-slate-700 uppercase tracking-wider">
                  Equipment Name
                </th>
                <th className="text-left px-6 py-3 text-xs font-medium text-slate-700 uppercase tracking-wider">
                  Team
                </th>
                <th className="text-left px-6 py-3 text-xs font-medium text-slate-700 uppercase tracking-wider">
                  Status
                </th>
                <th className="text-left px-6 py-3 text-xs font-medium text-slate-700 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredEquipment.map((eq) => {
                const team = getTeamById(eq.teamId);
                const maintenanceCount = getMaintenanceCount(eq.id);

                return (
                  <tr key={eq.id} className="hover:bg-slate-50 transition">
                    <td className="px-6 py-4 text-sm font-medium text-slate-900">{eq.name}</td>
                    <td className="px-6 py-4 text-sm text-slate-700">{team?.name}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded border ${getStatusColor(eq.status)}`}>
                        {eq.status.replace('_', ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedEquipment(eq.id)}
                          className="inline-flex items-center space-x-2 px-3 py-1.5 bg-slate-900 text-white text-sm rounded-lg hover:bg-slate-800 transition"
                        >
                          <History className="w-4 h-4" />
                          <span>Maintenance History ({maintenanceCount})</span>
                        </button>
                        {(currentUser?.role === 'manager') && (
                          <button
                            onClick={() => {
                              if (confirm('Delete this equipment and related requests?')) {
                                deleteEquipment(eq.id);
                              }
                            }}
                            className="inline-flex items-center px-3 py-1.5 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selectedEquipment && (
        <HistoryModal
          equipmentId={selectedEquipment}
          equipmentName={equipment.find((eq) => eq.id === selectedEquipment)?.name || ''}
          requests={requests}
          onClose={() => setSelectedEquipment(null)}
        />
      )}
    </div>
  );
};
