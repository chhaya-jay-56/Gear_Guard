import { useState } from 'react';
import { Navbar } from '../shared/Navbar';
import { ManagerStats } from './ManagerStats';
import { KanbanBoard } from '../technician/KanbanBoard';
import { Calendar } from '../technician/Calendar';
import { Equipment } from './Equipment';
import { Teams } from './Teams';

export const ManagerDashboard = () => {
  const [activeView, setActiveView] = useState('dashboard');

  const views = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'kanban', label: 'Kanban' },
    { id: 'calendar', label: 'Calendar' },
    { id: 'equipment', label: 'Equipment' },
    { id: 'teams', label: 'Teams' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar activeView={activeView} onViewChange={setActiveView} views={views} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'dashboard' && <ManagerStats />}
        {activeView === 'kanban' && <KanbanBoard showAllTeams={true} />}
        {activeView === 'calendar' && <Calendar showAllTypes={true} />}
        {activeView === 'equipment' && <Equipment />}
        {activeView === 'teams' && <Teams />}
      </div>
    </div>
  );
};
