import { useApp } from '../../contexts/AppContext';
import { isOverdue } from '../../utils/dateUtils';
import { AlertTriangle, Clock, CheckCircle } from 'lucide-react';

export const ManagerStats = () => {
  const { requests, teams } = useApp();

  const openRequests = requests.filter((req) => req.status !== 'repaired' && req.status !== 'scrap');
  const overdueRequests = openRequests.filter((req) => isOverdue(req.dueDate));
  const completedRequests = requests.filter((req) => req.status === 'repaired');

  const avgResolutionTime = () => {
    const completed = requests.filter((req) => req.status === 'repaired' && req.duration);
    if (completed.length === 0) return 0;
    const total = completed.reduce((sum, req) => sum + (req.duration || 0), 0);
    return (total / completed.length).toFixed(1);
  };

  const requestsByTeam = teams.map((team) => ({
    name: team.name,
    count: requests.filter((req) => req.teamId === team.id && req.status !== 'repaired' && req.status !== 'scrap').length,
  }));

  const maxCount = Math.max(...requestsByTeam.map((t) => t.count), 1);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Total Open</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">{openRequests.length}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Overdue</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">{overdueRequests.length}</p>
            </div>
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600">Avg Resolution Time</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">{avgResolutionTime()}h</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-bold text-slate-900 mb-4">Open Requests by Team</h3>
        <div className="space-y-4">
          {requestsByTeam.map((team) => (
            <div key={team.name}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-700">{team.name}</span>
                <span className="text-sm font-bold text-slate-900">{team.count}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div
                  className="bg-slate-900 h-2 rounded-full transition-all"
                  style={{ width: `${(team.count / maxCount) * 100}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
