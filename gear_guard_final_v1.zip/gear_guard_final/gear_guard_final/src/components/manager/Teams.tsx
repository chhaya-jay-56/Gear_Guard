import { useApp } from '../../contexts/AppContext';
import { useAuth } from '../../contexts/AuthContext';
import { Users, CheckCircle, Clock } from 'lucide-react';

export const Teams = () => {
  const { teams, requests } = useApp();
  const { users } = useAuth();

  const getTeamStats = (teamId: string) => {
    const teamRequests = requests.filter((req) => req.teamId === teamId);
    const openRequests = teamRequests.filter((req) => req.status !== 'repaired' && req.status !== 'scrap').length;
    const completedRequests = teamRequests.filter((req) => req.status === 'repaired').length;
    return { open: openRequests, completed: completedRequests };
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Teams Management</h2>
        <p className="text-slate-600 mt-1">Overview of all maintenance teams and their members</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {teams.map((team) => {
          const stats = getTeamStats(team.id);
          const teamMembers = users.filter((user) => team.members.includes(user.id));

          return (
            <div key={team.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-slate-900 p-2 rounded-lg">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">{team.name}</h3>
                    <p className="text-sm text-slate-600">{teamMembers.length} members</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="w-4 h-4 text-slate-600" />
                    <span className="text-sm font-medium text-slate-600">Open</span>
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{stats.open}</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-slate-600">Completed</span>
                  </div>
                  <p className="text-2xl font-bold text-slate-900">{stats.completed}</p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-slate-700 mb-3">Team Members</h4>
                <div className="space-y-2">
                  {teamMembers.map((member) => (
                    <div key={member.id} className="flex items-center space-x-3 p-2 bg-slate-50 rounded-lg">
                      <div className="bg-slate-900 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium">
                        {member.avatar}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-slate-900">{member.name}</p>
                        <p className="text-xs text-slate-600 capitalize">{member.role}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-slate-600">
                          {requests.filter((req) => req.assignedTo === member.id && req.status === 'in_progress').length} active
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
