import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { MaintenanceRequest, Equipment, Team, Status } from '../types';
import { initialRequests, initialEquipment, initialTeams } from '../utils/mockData';

const API_URL = (import.meta.env.VITE_API_URL as string) || 'http://localhost:5000';

interface AppContextType {
  requests: MaintenanceRequest[];
  equipment: Equipment[];
  teams: Team[];
  addRequest: (request: Omit<MaintenanceRequest, 'id' | 'createdAt'>) => void;
  updateRequest: (id: string, updates: Partial<MaintenanceRequest>) => void;
  deleteRequest: (id: string) => void;
  deleteEquipment: (id: string) => void;
  updateEquipment: (id: string, updates: Partial<Equipment>) => void;
  getEquipmentById: (id: string) => Equipment | undefined;
  getTeamById: (id: string) => Team | undefined;
  getUsersByTeamId: (teamId: string) => string[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [requests, setRequests] = useState<MaintenanceRequest[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [teams, setTeams] = useState<Team[]>(initialTeams);

  useEffect(() => {
    // try to load from backend, fall back to localStorage/mock data
    const load = async () => {
      try {
        const reqRes = await fetch(`${API_URL}/api/requests`);
        const eqRes = await fetch(`${API_URL}/api/equipment`);
        if (reqRes.ok && eqRes.ok) {
          const reqJson = await reqRes.json();
          const eqJson = await eqRes.json();
          const teamsRes = await fetch(`${API_URL}/api/teams`);
          const teamsJson = teamsRes.ok ? await teamsRes.json() : [];
          // map DB fields to frontend shape
          const mappedRequests: MaintenanceRequest[] = reqJson.map((r: any) => ({
            id: r.id,
            subject: r.subject,
            description: r.description,
            equipmentId: r.equipment_id,
            teamId: r.team_id,
            priority: r.priority,
            status: r.status,
            type: r.type,
            createdBy: r.created_by,
            createdAt: r.created_at,
            dueDate: r.due_date ? new Date(r.due_date).toISOString() : undefined,
            completedAt: r.completed_at ? new Date(r.completed_at).toISOString() : undefined,
          }));

          const mappedEquipment: Equipment[] = eqJson.map((e: any) => ({
            id: e.id,
            name: e.name,
            teamId: e.team_id,
            status: e.status,
          }));

          setRequests(mappedRequests);
          setEquipment(mappedEquipment);
          setTeams(teamsJson.map((t:any) => ({ id: t.id, name: t.name, members: t.members } )));
          localStorage.setItem('gearguard_requests', JSON.stringify(mappedRequests));
          localStorage.setItem('gearguard_equipment', JSON.stringify(mappedEquipment));
          localStorage.setItem('gearguard_teams', JSON.stringify(teamsJson));
          return;
        }
      } catch (e) {
        // backend not reachable
      }

      const savedRequests = localStorage.getItem('gearguard_requests');
      const savedEquipment = localStorage.getItem('gearguard_equipment');

      if (savedRequests) {
        setRequests(JSON.parse(savedRequests));
      } else {
        setRequests(initialRequests);
        localStorage.setItem('gearguard_requests', JSON.stringify(initialRequests));
      }

      if (savedEquipment) {
        setEquipment(JSON.parse(savedEquipment));
      } else {
        setEquipment(initialEquipment);
        localStorage.setItem('gearguard_equipment', JSON.stringify(initialEquipment));
      }
    };
    load();
  }, []);

  useEffect(() => {
    if (requests.length > 0) {
      localStorage.setItem('gearguard_requests', JSON.stringify(requests));
    }
  }, [requests]);

  useEffect(() => {
    if (equipment.length > 0) {
      localStorage.setItem('gearguard_equipment', JSON.stringify(equipment));
    }
  }, [equipment]);

  const addRequest = async (request: Omit<MaintenanceRequest, 'id' | 'createdAt'>) => {
    // try to persist to backend, fallback to local state
    try {
      const res = await fetch(`${API_URL}/api/requests`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request),
      });
      if (res.ok) {
        const json = await res.json();
        const newRequest: MaintenanceRequest = {
          ...request,
          id: json.id,
          createdAt: new Date().toISOString(),
        };
        setRequests((prev) => [...prev, newRequest]);
        return;
      }
    } catch (e) {
      // ignore, fallback
    }

    const newRequest: MaintenanceRequest = {
      ...request,
      id: `req${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setRequests((prev) => [...prev, newRequest]);
  };

  const updateRequest = async (id: string, updates: Partial<MaintenanceRequest>) => {
    try {
      await fetch(`${API_URL}/api/requests/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (e) {
      // continue to update local state even if backend fails
    }

    setRequests((prev) =>
      prev.map((req) => {
        if (req.id === id) {
          const updatedRequest = { ...req, ...updates };

          if (updates.status === 'repaired' || updates.status === 'scrap') {
            updatedRequest.completedAt = new Date().toISOString();
          }

          if (updates.status === 'scrap') {
            const eq = equipment.find((e) => e.id === req.equipmentId);
            if (eq) {
              updateEquipment(eq.id, { status: 'scrapped' });
            }
          }

          if (updates.status === 'in_progress' && req.status === 'new') {
            const eq = equipment.find((e) => e.id === req.equipmentId);
            if (eq && eq.status === 'operational') {
              updateEquipment(eq.id, { status: 'under_maintenance' });
            }
          }

          if ((updates.status === 'repaired' || updates.status === 'scrap') && req.status === 'in_progress') {
            const eq = equipment.find((e) => e.id === req.equipmentId);
            if (eq && eq.status === 'under_maintenance') {
              const otherActiveRequests = requests.filter(
                (r) => r.id !== id && r.equipmentId === req.equipmentId && (r.status === 'in_progress' || r.status === 'new')
              );
              if (otherActiveRequests.length === 0 && updates.status !== 'scrap') {
                updateEquipment(eq.id, { status: 'operational' });
              }
            }
          }

          return updatedRequest;
        }
        return req;
      })
    );
  };

  const deleteRequest = async (id: string) => {
    try {
      await fetch(`${API_URL}/api/requests/${id}`, { method: 'DELETE' });
    } catch (e) {
      // ignore
    }
    setRequests((prev) => prev.filter((r) => r.id !== id));
  };

  const updateEquipment = (id: string, updates: Partial<Equipment>) => {
    setEquipment((prev) =>
      prev.map((eq) => (eq.id === id ? { ...eq, ...updates } : eq))
    );
  };

  const deleteEquipment = async (id: string) => {
    try {
      await fetch(`${API_URL}/api/equipment/${id}`, { method: 'DELETE' });
    } catch (e) {
      // ignore
    }
    setEquipment((prev) => prev.filter((e) => e.id !== id));
    setRequests((prev) => prev.filter((r) => r.equipmentId !== id));
  };

  const getEquipmentById = (id: string) => {
    return equipment.find((eq) => eq.id === id);
  };

  const getTeamById = (id: string) => {
    return teams.find((team) => team.id === id);
  };

  const getUsersByTeamId = (teamId: string) => {
    const team = teams.find((t) => t.id === teamId);
    return team ? team.members : [];
  };

  return (
    <AppContext.Provider
      value={{
        requests,
        equipment,
        teams,
        addRequest,
        updateRequest,
        deleteRequest,
        deleteEquipment,
        updateEquipment,
        getEquipmentById,
        getTeamById,
        getUsersByTeamId,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
